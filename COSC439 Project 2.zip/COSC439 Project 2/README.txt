README - Custom OS Shell in C++

This shell program supports the following commands:

1. cd       - Change directory
2. ls       - List directory contents
3. dir      - Same as ls
4. pwd      - Print working directory
5. cat      - Display contents of files
6. echo     - Display arguments
7. mkdir    - Create directory
8. rmdir    - Remove directory
9. rm       - Remove file
10. cp      - Copy file
11. mv      - Move or rename file
12. touch   - Create empty file
13. chmod   - Change file permissions
14. chown   - Change file owner and group
15. wc      - Count lines, words, and characters in a file
16. grep    - Search for a pattern in a file
17. cls     - Clear the screen
18. environ - Display environment variables
19. help    - Show list of supported commands
20. exit    - Exit the shell

Compilation:
    g++ shell.cpp -o myshell

Execution:
    ./myshell
