/*
README - Custom OS Shell in C++
Author: Towson University - Operating Systems Project 2

This shell program supports the following commands:

1. cd       - Change directory
2. ls       - List directory contents
3. dir      - Same as ls
4. pwd      - Print working directory
5. cat      - Display contents of files
6. echo     - Display arguments
7. mkdir    - Create directory
8. rmdir    - Remove directory
9. rm       - Remove file
10. cp      - Copy file
11. mv      - Move or rename file
12. touch   - Create empty file
13. chmod   - Change file permissions
14. chown   - Change file owner and group
15. wc      - Count lines, words, and characters in a file
16. grep    - Search for a pattern in a file
17. cls     - Clear the screen
18. environ - Display environment variables
19. help    - Show list of supported commands
20. exit    - Exit the shell

Compilation:
    g++ shell.cpp -o myshell

Execution:
    ./myshell
*/

#include <iostream>
#include <unistd.h>
#include <cstring>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdlib>
#include <fstream>
#include <pwd.h>

using namespace std;

vector<string> split(const string& input) {
    stringstream ss(input);
    string token;
    vector<string> tokens;
    while (ss >> token) {
        tokens.push_back(token);
    }
    return tokens;
}

void executeCommand(const vector<string>& args) {
    if (args.empty()) return;

    string command = args[0];

    if (command == "exit") {
        exit(0);

    } else if (command == "cd") {
        if (args.size() > 1) {
            if (chdir(args[1].c_str()) != 0) {
                perror("cd failed");
            }
        } else {
            cerr << "cd: missing argument\n";
        }

    } else if (command == "pwd") {
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd)) != nullptr) {
            cout << cwd << endl;
        } else {
            perror("pwd failed");
        }

    } else if (command == "mkdir") {
        for (size_t i = 1; i < args.size(); ++i) {
            if (mkdir(args[i].c_str(), 0755) != 0) {
                perror("mkdir failed");
            }
        }

    } else if (command == "rmdir") {
        for (size_t i = 1; i < args.size(); ++i) {
            if (rmdir(args[i].c_str()) != 0) {
                perror("rmdir failed");
            }
        }

    } else if (command == "rm") {
        for (size_t i = 1; i < args.size(); ++i) {
            if (remove(args[i].c_str()) != 0) {
                perror("rm failed");
            }
        }

    } else if (command == "touch") {
        for (size_t i = 1; i < args.size(); ++i) {
            int fd = open(args[i].c_str(), O_CREAT | O_WRONLY, 0644);
            if (fd == -1) {
                perror("touch failed");
            } else {
                close(fd);
            }
        }

    } else if (command == "chmod") {
        if (args.size() >= 3) {
            mode_t mode = strtol(args[1].c_str(), nullptr, 8);
            for (size_t i = 2; i < args.size(); ++i) {
                if (chmod(args[i].c_str(), mode) != 0) {
                    perror("chmod failed");
                }
            }
        } else {
            cerr << "chmod: usage chmod <mode> <file1> <file2> ...\n";
        }

    } else if (command == "chown") {
        if (args.size() >= 3) {
            struct passwd *pw = getpwnam(args[1].c_str());
            if (!pw) {
                perror("chown failed");
                return;
            }
            for (size_t i = 2; i < args.size(); ++i) {
                if (chown(args[i].c_str(), pw->pw_uid, pw->pw_gid) != 0) {
                    perror("chown failed");
                }
            }
        } else {
            cerr << "chown: usage chown <user> <file1> <file2> ...\n";
        }

    } else if (command == "cp") {
        if (args.size() == 3) {
            ifstream src(args[1], ios::binary);
            ofstream dst(args[2], ios::binary);
            dst << src.rdbuf();
            if (!src || !dst) perror("cp failed");
        } else {
            cerr << "cp: usage cp <source> <destination>\n";
        }

    } else if (command == "mv") {
        if (args.size() == 3) {
            if (rename(args[1].c_str(), args[2].c_str()) != 0) {
                perror("mv failed");
            }
        } else {
            cerr << "mv: usage mv <source> <destination>\n";
        }

    } else if (command == "grep") {
        if (args.size() == 3) {
            ifstream file(args[2]);
            string line;
            while (getline(file, line)) {
                if (line.find(args[1]) != string::npos) {
                    cout << line << endl;
                }
            }
        } else {
            cerr << "grep: usage grep <pattern> <file>\n";
        }

    } else if (command == "wc") {
        if (args.size() == 2) {
            ifstream file(args[1]);
            string line;
            int lines = 0, words = 0, chars = 0;
            while (getline(file, line)) {
                ++lines;
                words += split(line).size();
                chars += line.size();
            }
            cout << "Lines: " << lines << ", Words: " << words << ", Characters: " << chars << endl;
        } else {
            cerr << "wc: usage wc <file>\n";
        }

    } else if (command == "cls") {
        system("clear");

    } else if (command == "dir") {
        system("ls");

    } else if (command == "ls") {
        system("ls");

    } else if (command == "cat") {
        if (args.size() >= 2) {
            for (size_t i = 1; i < args.size(); ++i) {
                ifstream file(args[i]);
                if (!file) {
                    perror("cat failed");
                    continue;
                }
                string line;
                while (getline(file, line)) {
                    cout << line << endl;
                }
            }
        } else {
            cerr << "cat: usage cat <file1> <file2> ...\n";
        }

    } else if (command == "echo") {
        for (size_t i = 1; i < args.size(); ++i) {
            cout << args[i] << " ";
        }
        cout << endl;

    } else if (command == "help") {
        cout << "Available commands:\ncd, ls, dir, pwd, cat, echo, mkdir, rmdir, rm, cp, mv, touch, chmod, chown, wc, grep, cls, environ, help, exit\n";

    } else if (command == "environ") {
        extern char **environ;
        for (int i = 0; environ[i]; ++i) {
            cout << environ[i] << endl;
        }

    } else {
        pid_t pid = fork();
        if (pid == 0) {
            vector<char*> c_args;
            for (const auto& arg : args) {
                c_args.push_back(const_cast<char*>(arg.c_str()));
            }
            c_args.push_back(nullptr);
            execvp(c_args[0], c_args.data());
            perror("exec failed");
            exit(1);
        } else if (pid > 0) {
            wait(nullptr);
        } else {
            perror("fork failed");
        }
    }
}

int main() {
    string input;
    while (true) {
        cout << "myshell> ";
        getline(cin, input);
        vector<string> args = split(input);
        executeCommand(args);
    }
    return 0;
}
